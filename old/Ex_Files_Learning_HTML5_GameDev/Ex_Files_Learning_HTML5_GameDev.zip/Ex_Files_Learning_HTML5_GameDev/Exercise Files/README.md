# html5-game-development-video-2nd-edition
HTML5 Game Development, Video Course, 2nd Edition

Please be sure to run the exercise files from a server as directed, not by double-clicking 
 with file:// protocol. Some will work via the file:// protocol, but eventually (04_03),
 the files will not work properly if run locally.

